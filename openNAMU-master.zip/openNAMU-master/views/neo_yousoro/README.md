## 개요
YouSoro 스킨의 공식적인 후속 스킨 입니다. 폴더명을 `neo_yousoro`로 변경한 후 `views` 폴더에 넣어주세요.
